#!/bin/sh -e

autoreconf -fi;
rm -Rf autom4te*.cache;
