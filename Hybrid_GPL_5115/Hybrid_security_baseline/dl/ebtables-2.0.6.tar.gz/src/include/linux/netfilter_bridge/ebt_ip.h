/*
 *  ebt_ip
 *
 *	Authors:
 *	Bart De Schuymer <bart.de.schuymer@pandora.be>
 *
 *  April, 2002
 *
 *  Changes:
 *    added ip-sport and ip-dport
 *    Innominate Security Technologies AG <mhopf@innominate.com>
 *    September, 2002
 */

#ifndef __LINUX_BRIDGE_EBT_IP_H
#define __LINUX_BRIDGE_EBT_IP_H

#ifdef BRIDGE_EBT_IP_IPRANGE
#define EBT_IP_SOURCE   0x0001
#define EBT_IP_DEST     0x0002
#define EBT_IP_TOS      0x0004
#define EBT_IP_PROTO    0x0008
#define EBT_IP_SPORT    0x0010
#define EBT_IP_DPORT    0x0020
#define EBT_IP_8021P    0x0040
#define EBT_IP_8021Q    0x0080
#define EBT_IP_SRANGE   0x0100
#define EBT_IP_DRANGE   0x0200
#else
#define EBT_IP_SOURCE   0x01
#define EBT_IP_DEST     0x02
#define EBT_IP_TOS      0x04
#define EBT_IP_PROTO    0x08
#define EBT_IP_SPORT    0x10
#define EBT_IP_DPORT    0x20
#define EBT_IP_8021P    0x40
#define EBT_IP_8021Q    0x80
#endif

#ifdef BRIDGE_EBT_IP_IPRANGE
#define EBT_IP_MASK (EBT_IP_SOURCE | EBT_IP_DEST | EBT_IP_TOS | EBT_IP_PROTO |\
 EBT_IP_SPORT | EBT_IP_DPORT | EBT_IP_8021P | EBT_IP_8021Q | EBT_IP_SRANGE | EBT_IP_DRANGE)
#else
#define EBT_IP_MASK (EBT_IP_SOURCE | EBT_IP_DEST | EBT_IP_TOS | EBT_IP_PROTO |\
 EBT_IP_SPORT | EBT_IP_DPORT | EBT_IP_8021P | EBT_IP_8021Q)
#endif
#define EBT_IP_MATCH "ip"

#ifdef BRIDGE_EBT_IP_IPRANGE
struct ebt_iprange {
	/* Inclusive: network order. */
	u_int32_t min_ip, max_ip;
};
#endif

/* the same values are used for the invflags */
struct ebt_ip_info
{
	uint32_t saddr;
	uint32_t daddr;
	uint32_t smsk;
	uint32_t dmsk;
	/* Start of modified by f00120964 for ipp/tos problem 2012-03-07 */
	//uint8_t  tos;
	uint32_t tos;
	/* End of modified by f00120964 for ipp/tos problem 2012-03-07 */
	
	uint8_t  protocol;
#ifdef BRIDGE_EBT_IP_IPRANGE   
	uint16_t  bitmask;
	uint16_t  invflags;
#else
    uint8_t  bitmask;
    uint8_t  invflags;
#endif
	uint16_t sport[2];
	uint16_t dport[2];
	uint16_t vlan_8021p;
	uint16_t vlan_8021q;
#ifdef BRIDGE_EBT_IP_IPRANGE       
    struct ebt_iprange src;
    struct ebt_iprange dst;
#endif    
};

#endif
