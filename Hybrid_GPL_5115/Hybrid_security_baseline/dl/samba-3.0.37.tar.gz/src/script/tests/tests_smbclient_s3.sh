. $SCRIPTDIR/test_smbclient_s3.sh $SERVER $SERVER_IP
